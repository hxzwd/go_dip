
package main


import (
	"fmt"
	"math"
	"sort"
)

func GetIndexByValue(values []int, value int) int {
	for i, v := range values {
		if value == v {
			return i
		}
	}
	return -1
}

func MinInSlice(values []int) int {
//	var tmp_arr []int
//	for _, value := range values {
//		tmp_arr = append(tmp_arr, int(value))
//	}
	tmp_arr := make([]int, len(values))
	copy(tmp_arr, values)
//	tmp_arr_2 := make([]int, len(tmp_arr))
//	copy(tmp_arr_2, tmp_arr)
	sort.Ints(tmp_arr)
//	fmt.Println(tmp_arr)
	pos := GetIndexByValue(values, tmp_arr[0])
//	pos := sort.SearchInts(values, tmp_arr[0])
//	fmt.Println(pos)
	return pos
}

func get_new_I_value(old_I uint8, bpp int) (uint8, uint8) {

	var new_I uint8
	var err_I uint8
	var tmp_arr []int
	num_of_new_color := int(math.Pow(2.0, float64(bpp)))
	color_part := int(255/(num_of_new_color - 1))
	tmp_arr = append(tmp_arr, 0)
	for i := 1; i < num_of_new_color - 1; i++ {
		tmp_arr = append(tmp_arr, color_part * i)
	}
	tmp_arr = append(tmp_arr, 255)
//	fmt.Println(tmp_arr)
	tmp_arr_2 := make([]int, len(tmp_arr))
	copy(tmp_arr_2, tmp_arr)
	for i := 0; i < len(tmp_arr); i++ {
		tmp_arr[i] = int(math.Abs(float64(int(old_I) - tmp_arr[i])))
	}
//	fmt.Println(tmp_arr)
	pos := MinInSlice(tmp_arr)

	new_I = uint8(tmp_arr_2[pos])
	err_I = old_I - new_I
//	fmt.Printf("new_I = %v\nerr_I = %v\n", new_I, err_I)
	return uint8(new_I), uint8(err_I)

}


func func_lab_4(img st_8bpp_image, new_bpp int) st_8bpp_image {

	fmt.Printf("Lab 4 func:\nNew bpp is %v\n", new_bpp)

	var res st_8bpp_image
	uint8_mat := img.make_matrix()

	var mat [][]float64
	for i := 0; i < img.h; i++ {
		var row []float64
		for j := 0; j < img.w; j++ {
			row = append(row, float64(uint8_mat[i][j])/255.0)
		}
		mat = append(mat, row)
	}

	for j := 0; j < img.h; j++ { // ROWS LOOP
		for i := 0; i < img.w; i++ {  // COLUMNS LOOP
			tmp_int := int(mat[j][i]*255)
			var new_I uint8
			var err_I int
			var err_UI8 uint8
			if tmp_int > 255 {
				new_I = uint8(255)
				err_I = tmp_int - int(new_I)
			} else if tmp_int < 0 {
				new_I = uint8(0)
				err_I = tmp_int - int(new_I)
			} else {
				new_I, err_UI8 = get_new_I_value(uint8(tmp_int), new_bpp)
				err_I = int(err_UI8)
			}
			mat[j][i] = float64(new_I)/255.0
			if i + 1 < img.w {
				mat[j][i + 1] += 7.0/16.0*float64(err_I)/255.0
				if j + 1 < img.h {
					mat[j + 1][i + 1] += 1.0/16.0*float64(err_I)/255.0
					mat[j + 1][i] += 5.0/16.0*float64(err_I)/255.0
					if i - 1 >= 0 && i - 1 < img.w {
						mat[j + 1][i - 1] += 3.0/16.0*float64(err_I)/255.0
					}
				} else {
					mat[j][i + 1] += 9.0/16.0*float64(err_I)/255.0
				}
			} else {
				if j + 1 < img.h {
					mat[j + 1][i] += 13.0/16.0*float64(err_I)/255.0
					mat[j + 1][i - 1] += 3.0/16.0*float64(err_I)/255.0
				}
			}
		}
	}

	for i := 0; i < img.h; i++ {
		for j := 0; j < img.w; j++ {
			tmp_int := int(mat[i][j]*255)
			if tmp_int > 255 {
				uint8_mat[i][j] = uint8(255)
			} else {
				uint8_mat[i][j] = uint8(tmp_int)
			}
			if tmp_int < 0 {
				uint8_mat[i][j] = uint8(0)
			}
		}
	}

	res.from_matrix(uint8_mat)

	return res

}


func func_lab_4_backup(img st_8bpp_image, new_bpp int) st_8bpp_image {

	fmt.Printf("Lab 4 func:\nNew bpp is %v\n", new_bpp)

	var res st_8bpp_image
	mat := img.make_matrix()



	for j := 0; j < img.h; j++ { // ROWS LOOP
		if (j % 2) == 0 {
			for i := 0; i < img.w; i++ {  // COLUMNS LOOP
				new_I, err_I := get_new_I_value(mat[j][i], new_bpp)
				mat[j][i] = new_I
				if i + 1 < img.w {
					mat[j][i + 1] += uint8(7.0/16.0*float64(err_I))
					if j + 1 < img.h {
						mat[j + 1][i + 1] += uint8(1.0/16.0*float64(err_I))
						mat[j + 1][i] += uint8(5.0/16.0*float64(err_I))
						if i - 1 >= 0 && i - 1 < img.w {
							mat[j + 1][i - 1] += uint8(3.0/16.0*float64(err_I))
						}
					}
				}
			}
		} else {
			for i := img.w - 1; i >= 0; i-- {
				new_I, err_I := get_new_I_value(mat[j][i], new_bpp)
				mat[j][i] = new_I
				if i - 1 < img.w && i - 1 >= 0 {
					mat[j][i - 1] += uint8(7.0/16.0*float64(err_I))
					if j + 1 < img.h {
						mat[j + 1][i - 1] += uint8(1.0/16.0*float64(err_I))
						mat[j + 1][i] += uint8(5.0/16.0*float64(err_I))
						if i + 1 >= 0 && i + 1 < img.w {
							mat[j + 1][i + 1] += uint8(3.0/16.0*float64(err_I))
						}
					}
				}

/*
				if j == 0 && i == img.w - 1 {
					mat[j][i] =  new_I
					mat[j - 1]
					continue
				}

				mat[j][i] = new_I
				mat[j][i - 1] += uint8(7.0/16.0*float64(err_I))
				mat[j + 1][i + 1] += uint8(3.0/16.0*float64(err_I))
				mat[j + 1][i] += uint8(5.0/16.0*float64(err_I))
				mat[j + 1][i - 1] += uint8(1.0/16.0*float64(err_I))
*/
			}
		}

	}

/*
	for i := 1; i < 8; i++ {
		get_new_I_value(163, i)
	}
*/

	res.from_matrix(mat)

	return res

}
